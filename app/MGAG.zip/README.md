# MGAG
Mobile Games Automatic Generator

npm install

bower install

npm start